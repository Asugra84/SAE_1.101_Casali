#include <iostream>
#include <vector>
#include <bits/stdc++.h>
#include <sstream>


using namespace std;

unsigned indiceMax(const vector<int> & tab){
    unsigned indice = 0;

    for (unsigned i = 0; i < tab.size(); ++i ) {
        if(tab[indice] < tab[i]){
            indice = i;
        }
    }
    return indice;
}


int main()
{


    vector<string> nomJeu {"Counter Strike","Streeet Fighter II", "Civilisation VI", "Mario Kart"};
    vector<int> cmptJeu {0, 0, 0, 0};


    while (true)
    {
        string ligne;
        // ligne 1 useless
        getline(cin, ligne);
        if(cin.eof()) break;
        // ligne 2 useless
        getline(cin, ligne);
        if(cin.eof()) break;
        // ligne 3 vote nega / posi ...
        getline(cin, ligne);
        if(ligne == "0") {
            // ligne 4
            getline(cin, ligne);




        } else if(ligne == "1") {
            // ligne 4
            getline(cin, ligne);
            if(cin.eof()) break;
            int vote;
            istringstream iss(ligne);
            iss >> vote;
            cmptJeu[vote-1] = cmptJeu[vote-1]+=1;



        } else if(ligne == "2" ) {
            // ligne 4
            getline(cin, ligne);
            if(cin.eof()) break;
            int vote;
            istringstream iss(ligne);
            iss >> vote;
            cmptJeu[vote-1] = cmptJeu[vote-1]-=1;
        }
    }
    unsigned indiceMaxGagnant = indiceMax(cmptJeu);
    cout << "Le gagnant du sondage est "<< nomJeu[indiceMaxGagnant] << endl;
}
