#include <iostream>
#include <vector>
#include "election.h"
using namespace std;

int main(){
    Election electionObjet;
    do
    {
        electionObjet.recuperationVote();
    } while(!cin.eof());
    electionObjet.resultatElection();
    return 0;
}
