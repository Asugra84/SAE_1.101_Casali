#ifndef ELECTION_H
#define ELECTION_H
#include <iostream>
#include <vector>
using namespace std;
class Election
{
private:
    int bulletinNul = 0;
    vector<int> voteCompteur {0,0,0,0};
    vector<string> participantVoteVariable = {"CSGO", "Street Fighter 2", "Civilisation VI", "Mario Kart"};
    int tailleParticipant = participantVoteVariable.size();
    vector<int> voteVector;
    vector<string> nomVector;
public:
    Election();
    unsigned indiceMax(const vector<int> & tab);
    void recuperationVote();
    void resultatElection();
};

#endif // ELECTION_H
