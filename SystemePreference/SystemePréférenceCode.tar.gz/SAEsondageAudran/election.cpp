#include "election.h"
#include <sstream>
Election::Election()
{
    for(int i = 0; i < tailleParticipant; ++i) {
        cout << "Participant : " << participantVoteVariable[i] << endl << endl;
    }
}
unsigned Election::indiceMax(const vector<int> & tab){
    unsigned indice = 0;

    for (unsigned i = 0; i < tab.size(); ++i ) {
        if(tab[indice] < tab[i]){
            indice = i;
        }
    }
    return indice;
}
void Election::recuperationVote(){
    while(true) {
        string ligne;
        getline(cin, ligne);
        if(cin.eof()) break;
        getline(cin, ligne);
        if(cin.eof()) break;

        // vote 3 points

        getline(cin, ligne);
        if(cin.eof()) break;
        int vote;
        istringstream iss(ligne);
        iss >> vote;
        voteCompteur[vote] += 3;

        // vote 2 points

        getline(cin, ligne);
        if(cin.eof()) break;
        int vote2;
        istringstream iss2(ligne);
        iss2 >> vote2;
        voteCompteur[vote2] += 2;

        // vote 1 point

        getline(cin, ligne);
        if(cin.eof()) break;
        int vote3;
        istringstream iss3(ligne);
        iss3 >> vote3;
        voteCompteur[vote3] += 1;

    }
}
void Election::resultatElection() {
    unsigned indiceGagnant = indiceMax(voteCompteur);
    cout << "Le gagnant du vote est : " << participantVoteVariable[indiceGagnant] << endl << endl;
}
