#include "election.h"
#include <sstream>
Election::Election()
{
    for(int i = 0; i < tailleParticipant; ++i) {
        cout << "Liste des candidats :  " << participantVoteVariable[i] << endl;
    }
    cout << endl << endl;
}
unsigned Election::indiceMax(const vector<int> & tab){
    unsigned indice = 0;

    for (unsigned i = 0; i < tab.size(); ++i ) {
        if(tab[indice] < tab[i]){
            indice = i;
        }
    }
    return indice;
}
void Election::recuperationVote(){
    while(true){
        string ligne;
        getline(cin, ligne);
        if(cin.eof()) break;
        getline(cin, ligne);
        getline(cin, ligne);
        int vote;
        istringstream iss(ligne);
        iss >> vote;
        voteCompteur[vote-1] += 1;

    }

}
void Election::resultatElection() {
    unsigned indiceGagnant = indiceMax(voteCompteur);
    cout << "Le gagnant du vote est : " << participantVoteVariable[indiceGagnant] << endl << endl;
}
